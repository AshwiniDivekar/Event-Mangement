import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pay-message',
  templateUrl: './pay-message.component.html',
  styleUrls: ['./pay-message.component.css']
})
export class PayMessageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
